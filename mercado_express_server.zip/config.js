const configuration = {
    mongodb :{
        url: "mongodb+srv://r00tULSA:r00tULSA@cluster1.zonto2i.mongodb.net/mercado-express"
    },
    jwt: {
        secretKey: "PPI"
    }
}

module.exports = {
    configuration
}
